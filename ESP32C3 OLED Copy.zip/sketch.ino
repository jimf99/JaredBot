#include <Wire.h>
#include <U8g2lib.h>

#define SDA_PIN 5
#define SCL_PIN 6

U8G2_SSD1306_72X40_ER_F_HW_I2C u8g2(U8G2_R0, U8X8_PIN_NONE);

unsigned long lastMs = 0;
uint32_t seconds = 0;

void setup() {
  Wire.begin(SDA_PIN, SCL_PIN);
  u8g2.begin();
  u8g2.setFont(u8g2_font_6x12_tf);
}

void drawScreen() {
  u8g2.clearBuffer();

  // Judul
  u8g2.drawStr(0, 12, "ESP32-C3");
  u8g2.drawStr(0, 24, "THE EGG");

  // Counter detik
  char buf[20];
  snprintf(buf, sizeof(buf), "t=%lus", (unsigned long)seconds);
  u8g2.drawStr(0, 38, buf);

  u8g2.sendBuffer();
}

void loop() {
  unsigned long now = millis();
  if (now - lastMs >= 1000) {
    lastMs = now;
    seconds++;
    drawScreen();
  }
}
